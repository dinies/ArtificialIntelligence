:- use_module(library(clpfd)).

australia(Vars) :-

	Vars = [WA, NT, Q, SA, NSW, V, T],

	Vars ins 1..3,

	all_different([WA, NT, SA]),
	all_different([NT, Q, SA]),
	all_different([SA, Q, NSW]),
	all_different([SA, NSW, V]),
	label(Vars).