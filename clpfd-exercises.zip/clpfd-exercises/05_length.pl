:- use_module(library(clpfd)).

test_length(X,Y) :-
	length(X,Y).