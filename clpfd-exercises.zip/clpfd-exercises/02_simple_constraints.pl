:- use_module(library(clpfd)).

simple_constraint(Vars) :-
	Vars=[A,B,C,D],
	Vars ins 1..4,
	A #< B,
	B #= C,
	C #< D,
	label(Vars).