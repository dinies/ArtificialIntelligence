:- use_module(library(clpfd)).

single_domain(X) :-
    X in 0..10,
    label([X]).
    
multiple_domain(Y) :-
	Y in 0..3 \/ 8..10,
	label([Y]).
	
list_domain(Vars) :-
	Vars=[A,B],
	Vars ins 1..3,
	label(Vars).