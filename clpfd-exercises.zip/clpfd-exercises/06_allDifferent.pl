:- use_module(library(clpfd)).

test_all_diff(Vars) :-
	Vars = [A, B, C],
	Vars ins 1..3,
	all_different([A, B, C]),
	label(Vars).