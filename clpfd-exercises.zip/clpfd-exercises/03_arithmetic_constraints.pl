:- use_module(library(clpfd)).

csp_factorial(0, 1).

csp_factorial(N, F) :-
	N #> 0,
	N1 #= N - 1,
	F #= N * F1,
	csp_factorial(N1, F1).