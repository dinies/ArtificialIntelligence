:- use_module(library(clpfd)).

logical_constraint(Vars) :-
	Vars=[A,B,C,D],
	Vars ins 1..4,
	A #= B,
	A #= B #==> C #= D,
	label(Vars).