:- use_module(library(clpfd)).

test_chain(Vars) :-
	Vars=[A,B,C,D],
	Vars ins 1..5,
    chain(Vars, #<),
    label(Vars).